# -*- coding: utf-8 -*-
"""
Created on Thu Nov 16 10:20:37 2023

@author: Leonardo
"""

# -*- coding: utf-8 -*-
"""
Created on Sat Nov 11 11:34:35 2023

@author: Leonardo
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Nov 10 10:27:55 2023

@author: Leonardo

"""
import os

def translate(s):
    traduttore={'0':'A','1':'B','2':'C','3':'D','4':'E','5':'F','6':'G',' ':'P','-':'b','+':'#',
                '0-':'Ab','0+':'A#','1-':'Bb','1+':'B#','2-':'Cb','2+':'C#','3-':'Db','3+':'D#',
                '4-':'Eb','4+':'E#','5-':'Fb','5+':'F#','6-':'Gb','6+':'G#'}
    sub,nwtxt,tot,cont,i='','',0,1,0
    while i<len(s):
        if i < len(s)-1:
            cont,i,sub,tot,nwtxt=ck_char(s, i, sub, cont, tot, nwtxt)
        else:
            if s[i]==sub:
                nwtxt+=traduttore[sub]+str(cont+1)
                tot+=cont+1
                break
            else:
                nwtxt+=traduttore[sub]+str(cont)+traduttore[s[i]]+'1'
                tot+=cont+1
                break
    if i==len(s):
        nwtxt+=traduttore[sub]+str(cont)
        tot+=cont
        
                    
    return nwtxt,tot
                    
def ck_char(s,i,sub,cont,tot,nwtxt):
    traduttore={'0':'A','1':'B','2':'C','3':'D','4':'E','5':'F','6':'G',' ':'P','-':'b','+':'#',
                '0-':'Ab','0+':'A#','1-':'Bb','1+':'B#','2-':'Cb','2+':'C#','3-':'Db','3+':'D#',
                '4-':'Eb','4+':'E#','5-':'Fb','5+':'F#','6-':'Gb','6+':'G#'}
    for j in list(range(1,3))[::-1]:
        if s[i:i+j] in traduttore:
            if s[i:i+j]==sub:
                cont+=1
                i+=j
                return cont,i,sub,tot,nwtxt
            else:
                if i==0:
                    sub=s[i:i+j]
                    cont=1
                    i+=j
                    return cont,i,sub,tot,nwtxt

                else:    
                    nwtxt+=traduttore[sub]+str(cont)
                    tot+=cont
                    sub=s[i:i+j]
                    cont=1
                    i+=j
                    return cont,i,sub,tot,nwtxt
            

def translate_files(nomi2,diz,lista_dir,source_root,final_dir):
    
    return diz



                        

#leggere ogni liena dell'indice composta da (nome canzone , nome file) 
#e ritornare due liste : titoli=[nome1,nome2,...] e filename[file1,...]



'''inverto ordine da inizio a fine di lista di righe di file a unica stringa'''
def inverti(lista) -> str:
    s=''
    for st in lista:
        s+=st[::-1]
    return s

def read_index(source_root,final_dir):
    nomi_file=[]
    nomi2=[]
    lista_dir=[]
    diz={}
    #leggiamo dall'indice titoli e nomii file da tradurre e li aggiungiamo alle corrispettive liste
    with open(source_root+'\\index.txt',mode='r') as fr:
         c=1
         lista=fr.read()
         lista=lista.replace('\n',' ')
         lista=lista.split('"')
         for nome in lista[1:]:
             if nome!=' ' and c==1 :
             
                 diz[nome]=0
                 c=2
             
             elif nome!=' ' and c==2 and'/' not in nome:
                nomi_file.append(nome)
                c=1
                lista_dir.append('')
                nomi2.append(nome)
                
             elif nome!=' ' and c==2 and'/'  in nome:
                nomi_file.append(nome)
                c=1
                nome=nome.replace('/','\\')
                i=nome[::-1].find('\\')
                lista_dir.append(nome[:len(nome)-i])
                nomi2.append(nome[len(nome)-i:])
                #diz[nome[len(nome)-i:]]=0
                os.makedirs(final_dir+'\\'+(nome[:len(nome)-i-1]),exist_ok=True)
    
    return nomi2,diz,lista_dir
                
def Umkansanize(source_root:str, target_root:str) -> dict[str,int]:
    
    final_dir=target_root



    #creo la caertella finale 
    os.makedirs(final_dir,exist_ok=True)


    nomi2,diz,lista_dir=read_index(source_root,final_dir)
    #prendo la directory dal nome

    for i,(f,d) in enumerate(zip(nomi2,diz)):
        
        with open(source_root+'\\'+lista_dir[i]+f,mode='r') as fr:
            lista=(fr.read()).split('\n')
            s=inverti(lista)
        
        ttradotto,diz[d]=translate(s)
    #file_tradotti.append(ttradotto)
        with open(final_dir+'\\'+lista_dir[i]+str(d)+'.txt', mode='w') as fr:
            fr.write(ttradotto)
            
    
    diz2={}
   
    with open(final_dir+'\\index.txt',mode='w') as fr:
        for c,v in sorted(diz.items(),key=lambda tupla: (-tupla[1],tupla[0])):
                      
            diz2[c]=v
            fr.write('"'+c+'"'+' '+str(v)+'\n')
        

    return  diz2

if __name__ == "__main__":
    print(Umkansanize('test02','test02.out'))
                