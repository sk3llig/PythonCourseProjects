# -*- coding: utf-8 -*-
"""
Created on Thu Nov  2 11:45:27 2023

@author: Leonardo
"""



def ex1(ftesto,a,b,n):
    # inserite qui il vostro codice
    #converto ill file di testo in stringa senza \n
    
    final_string=''

    with open(ftesto,mode='r') as fr:
        final_string=''
        for i,line in enumerate(fr):
            final_string+=line[:len(line)-1]  
            print('a')
    diz=sub_string(final_string,a,b)
    di2={}
    return diz
    #creo un diz2 con le chiavi la frequenza e valori tutte le sotto stringhe
    #con quella frequenza
    li=((list(set(diz.values())))[-1:-n+1:-1])
    
    '''for c,v in sorted(diz.items()):
        di2[v]=di2.get(v,[])+[c]
        print('s')
     '''   
    
    
#lista di n freq 


def sub_string(lista,a,b):
 diz={}
 for n in range(len(lista)):
     if n+a>len(lista): return diz
     for x in range(a,b+1):
         if n+x>len(lista): break
         diz[lista[n:n+x]]=diz.get(lista[n:n+x],0)+1
         print('b')
 return diz


di={'01': 15,
 '010': 10,
 '0101': 2,
 '10': 15,
 '101': 3,
 '1010': 2,
 '0100': 8,
 '100': 12,
 '1001': 7,
 '00': 23,
 '001': 11,
 '0010': 7,
 '1000': 5,
 '000': 11,
 '0001': 4,
 '0011': 4,
 '011': 5,
 '0111': 3,
 '11': 11,
 '111': 6,
 '1111': 3,
 '1110': 3,
 '110': 5,
 '1101': 1,
 '1011': 1,
 '0110': 2,
 '1100': 4,
 '0000': 6}




'''def ex1(ftesto,a,b,n):
    # inserite qui il vostro codice
    #converto ill file di testo in stringa senza \n
    
    lista=''.join(((open(ftesto,'r')).read()).split('\n'))
    
    diz=sub_string(lista,a,b)
    di2={}
    #creo un diz2 con le chiavi la frequenza e valori tutte le sotto stringhe
    #con quella frequenza
    
    for c,v in diz.items():
        di2[v]=di2.get(v,[])+[c]
        
    l=[]
    
    n1=0
    for k in sorted(di2.keys(),reverse=True):
        n1+=1
        if n1>n: break
        l.append((k,sorted(di2[k],key= lambda elem: elem)))   
    
    return l[::-1]

'''





