# -*- coding: utf-8 -*-
"""
Created on Fri Sep 29 18:06:45 2023

@author: Leonardo
"""

def xkcd_to_list_of_weights(xkcd : str) -> list[int]:
    '''
    Spezza una stringa in codifica XKCD nella corrispondente
    lista di interi, ciascuno corrispondente al peso di una lettera romana

    Parameters
    xkcd : str              stringa nel formato XKCD
    Returns
    list[int]               lista di 'pesi' corrispondenti alle lettere romane

    Esempio: '10010010010100511' -> [100, 100, 100, 10, 100, 5, 1, 1,]
    '''
    # INSERISCI QUI IL TUO CODICE
    somma=''
    l=[] 
    for i in range(len(xkcd)):
            if xkcd[i]!= '0':
                somma=xkcd[i]
                for c in range(i+1,len(xkcd)):
                    if int(xkcd[c])==0:
                        somma+=xkcd[c]
                    else:
                        break
                l.append(int(somma))
    return l
















def decode_value(xkcd : str ) -> int:
    '''
    Decodifica un valore nel formato XKCD e torna l'intero corrispondente.

    Parameters
    xkcd : str                  stringa nel formato XKCD
    Returns
    int                         intero corrispondente
    
    Esempio: '10010010010100511' -> 397
    '''
    # INSERISCI QUI IL TUO CODICE
    return list_of_weights_to_number(xkcd_to_list_of_weights(xkcd))




def decode_XKCD_tuple(xkcd_values : tuple[str, ...], k : int) -> list[int]:
    '''
    Riceve una lista di stringhe che rappresentano numeri nel formato XKCD
    ed un intero k positivo.
    Decodifica i numeri forniti e ne ritorna i k maggiori.

    Parameters
    valori_xkcd : list[str]     lista di stringhe in formato XKCD
    k : int                     numero di valori da tornare
    Returns
    list[int]                   i k massimi valori ottenuti in ordine decrescente
    '''
    # INSERISCI QUI IL TUO CODICE
    l=[]
    l2=[]
    for c in range(len(xkcd_values)):
        l.append(decode_value(xkcd_values[c]))
    for i in range(k):
        l2.append(max(l))
        l.remove(max(l))
    
    return l2 


def list_of_weights_to_number(weigths : list[int] ) -> int:
    '''
    Trasforma una lista di 'pesi' nel corrispondente valore arabo
    tenendo conto della regola di sottrazione

    Parameters
    lista_valori : list[int]    lista di 'pesi' di lettere romane
    Returns
    int                         numero arabo risultante
    
    Esempio: [100, 100, 100, 10, 100, 5, 1, 1,] -> 397
    '''
    # INSERISCI QUI IL TUO CODICE
    somma=0
    som2=0
    for i in range(len(weigths)):
        
        if i == len(weigths)-1:
            
            somma+=weigths[i]+som2
            
        elif i < len(weigths)-1:
            if weigths[i]> weigths[i+1]:
                som2+=weigths[i]
                somma+=som2
                som2=0
                
            elif weigths[i]==weigths[i+1]:
              
                som2+=weigths[i]
                
            elif weigths[i] < weigths[i+1]:
                som2+=weigths[i]
                somma-=som2
                som2=0
        print(somma,som2)
    return somma

print(list_of_weights_to_number( [100, 100, 100, 10, 100, 5, 1,1] ))





   