# -*- coding: utf-8 -*-

''' 
Abbiamo una stringa int_seq contenente una sequenza di interi non-negativi
    separati da virgole ed un intero positivo subtotal.

Progettare una funzione ex1(int_seq, subtotal) che
    riceve come argomenti la stringa int_seq e l'intero subtotal e
    restituisce il numero di sottostringhe di int_seq
    la somma dei cui valori è subtotal.

Ad esempio, per int_seq='3,0,4,0,3,1,0,1,0,1,0,0,5,0,4,2' e subtotal=9,
    la funzione deve restituire 7.

Infatti:
'3,0,4,0,3,1,0,1,0,1,0,0,5,0,4,2'
 _'0,4,0,3,1,0,1,0'_____________
 _'0,4,0,3,1,0,1'_______________
 ___'4,0,3,1,0,1,0'_____________
____'4,0,3,1,0,1'_______________
____________________'0,0,5,0,4'_
______________________'0,5,0,4'_
 _______________________'5,0,4'_

NOTA: è VIETATO usare/importare ogni altra libreria a parte quelle già presenti

NOTA: il timeout previsto per questo esercizio è di 1 secondo per ciascun test (sulla VM)

ATTENZIONE: quando caricate il file assicuratevi che sia nella codifica UTF8
    (ad esempio editatelo dentro Spyder)
'''
    


def ex1(int_seq, subtotal):
        ca=0
        s=list(map(int,int_seq.split(",")))
        zero=0
       
        if len(list(set(s)))==1:
            if subtotal % s[0] == 0: 
                return len(s)-(subtotal//s[0])+1
            else: return 0
        
        for i in range(0,len(s)):
            somma=0
            if s[i]==0:
                zero+=1
                continue
            if s[i]<= subtotal:
                for c in range(i,len(s)):
                    somma+=s[c]
                    if somma > subtotal:
                        break
                    elif somma==subtotal:
                        ca+=1+zero
            zero=0
                    
        return ca
    
if __name__ == '__main__':
    # Inserisci qui i tuoi test personali
    pass
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    